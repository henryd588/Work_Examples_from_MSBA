USE my_guitar_shop;


### Question 6
SELECT c.category_name, p.product_name, p.list_price
FROM products AS p
JOIN categories AS c
ON c.category_id = p.category_id
ORDER BY c.category_name, p.product_name ASC;

### Question 7
SELECT c.first_name, c.last_name, a.line1, a.city, a.state, a.zip_code
FROM addresses AS a
JOIN customers AS c
ON c.customer_id = a.customer_id
WHERE c.email_address = 'allan.sherwood@yahoo.com';

### Question 8
SELECT c.first_name, c.last_name, a.line1, a.city, a.state, a.zip_code
FROM customers AS c INNER JOIN addresses AS a
ON c.customer_id = a.customer_id
WHERE a.address_id = c.shipping_address_id;



### Question 9
SELECT c.first_name, c.last_name, o.order_date, p.product_name, i.item_price, i.discount_amount, i.quantity
FROM customers AS c JOIN orders AS o
ON c.customer_id = o.customer_id
JOIN order_items AS i
ON o.order_id = i.order_id
JOIN products AS p
ON i.product_id = p.product_id
ORDER BY c.last_name, o.order_date, p.product_name;

### Question 10
SELECT p1.product_name, p1.list_price
FROM products AS p1
JOIN products AS p2
ON p1.product_name != p2.product_name AND p1.list_price = p2.list_price
ORDER BY product_name;

### Question 11
SELECT 'NOT SHIPPED' AS ship_status, order_id, order_date
FROM orders
WHERE ship_date IS NULL 
UNION SELECT 'SHIPPED' AS ship_status, order_id, order_date
FROM orders
WHERE ship_date IS NOT NULL
ORDER BY order_date DESC;

### Question 12
SELECT c.category_name, COUNT(p.product_id) AS Count, MAX(p.list_price) AS Max_Price
FROM categories AS c
JOIN products AS p
ON c.category_id = p.category_id
GROUP BY c.category_name
ORDER BY Count DESC;

### Question 13
SELECT c.email_address, COUNT(i.order_id) AS total_orders, ((i.item_price - i.discount_amount) * i.quantity) AS order_total
FROM customers AS c
JOIN orders AS o
ON c.customer_id = o.customer_id
JOIN order_items AS i
ON o.order_id = i.order_id
GROUP BY c.customer_id
HAVING total_orders > 1
ORDER BY order_total DESC;

### Question 14
SELECT c.email_address, COUNT(DISTINCT i.product_id) AS product_count
FROM customers AS c
JOIN orders AS o
ON c.customer_id = o.customer_id
JOIN order_items AS i
ON o.order_id = i.order_id
GROUP BY c.customer_id
HAVING product_count > 1;

### Question 15
SELECT product_name, list_price
FROM products AS p
WHERE list_price >
	(SELECT AVG(list_price)
    FROM Products)
ORDER BY list_price DESC;

### Question 16
SELECT category_name
FROM categories AS c
WHERE NOT EXISTS
	(SELECT *
    FROM products AS p
    WHERE p.category_id = c.category_id);
    
### Question 17
SELECT email_address, MAX(order_total) as max_total
FROM (SELECT c.email_address, i.order_id, (o.tax_amount + o.ship_amount + (i.item_price - i.discount_amount)* i.quantity) AS order_total
FROM customers AS c
JOIN orders AS o
ON o.customer_id = c.customer_id
JOIN order_items AS i
ON i.order_id = o.order_id
GROUP BY email_address, o.order_id) AS order_total_table
GROUP BY email_address
ORDER BY max_total DESC;


### Question 18
SELECT product_name, discount_percent
FROM products
WHERE discount_percent NOT IN(
SELECT discount_percent
FROM products
GROUP BY discount_percent
HAVING COUNT(discount_percent) > 1)
ORDER BY product_name;

### Question 19
SELECT list_price, 
FORMAT(list_price, 1) AS formatted_list_price,
CONVERT(list_price, UNSIGNED) AS converted_list_price,
CAST(list_price AS UNSIGNED) AS cast_list_price,
date_added,
CAST(date_added AS DATE) AS cast_date,
CAST(date_added AS CHAR(7)) AS cast_date_no_day,
CAST(date_added AS TIME) AS time_date
FROM products;

### Question 20
SELECT card_number, LENGTH(card_number) AS card_num_len, SUBSTR(card_number, -4, 4) AS last_four, CONCAT('XXXX-XXXX-XXXX-', SUBSTR(card_number, -4, 4)) AS xxxx_last_four
FROM orders;